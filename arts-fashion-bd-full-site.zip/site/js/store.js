/* ============================================================
   Arts Fashion BD — shared data layer
   Used by every page (site + admin) so cart, stock and invoices
   all stay in sync across the whole project.

   Persistence: browser localStorage.
   NOTE: this is a same-browser demo store — good for showing how
   the whole system connects end to end. A real production build
   replaces this file's storage with a real database + backend API
   so stock/invoices are shared across every visitor's device.
   ============================================================ */

const AF_KEYS = {
  products: 'af_products',
  cart: 'af_cart',
  invoices: 'af_invoices',
  invoiceCounter: 'af_invoice_counter',
  productCodeCounter: 'af_product_code_counter'
};

const AF_DEFAULT_PRODUCTS = [
  {id:1, name:"Brazil player edition jersey", sku:"AF-BRA-01", cat:"Sports", label:"BRA", price:650, stock:24, lowAt:8, badge:"World Cup",
   desc:"Premium quality sports jersey made with smooth, breathable polyester fabric. Built for match-day comfort with a true-to-size athletic fit, moisture-wicking finish, and durable print that holds up wash after wash.",
   sizes:["S","M","L","XL","2XL"], colors:["#FDDE00","#0C447C"]},
  {id:2, name:"Men's classic polo", sku:"AF-POL-02", cat:"Men", label:"10", price:550, stock:5, lowAt:8,
   desc:"100% combed compact cotton PK polo. Soft touch fabric designed for day-long comfort, with a clean tailored fit suitable for both casual and semi-formal wear.",
   sizes:["S","M","L","XL"], colors:["#FFFFFF","#173404"]},
  {id:3, name:"Kids premium t-shirt", sku:"AF-KID-03", cat:"Kids", label:"KID", price:250, stock:40, lowAt:10,
   desc:"Soft, breathable combed compact cotton t-shirt made for all-day play. Colourfast print and a compact finish that keeps its shape and size wash after wash.",
   sizes:["2-3Y","4-5Y","6-7Y","8-9Y"], colors:["#E24B4A","#378ADD"]},
  {id:4, name:"Sports combo jersey pack", sku:"AF-CMB-04", cat:"Combo", label:"3IN1", price:999, stock:0, lowAt:5, badge:"-5%",
   desc:"A 3-in-1 value pack of our best-selling sports jerseys. Same premium polyester fabric as our single jerseys, bundled at a discounted price — ideal for training groups or gifting.",
   sizes:["M","L","XL"], colors:["#10151F","#C8283B","#0C447C"]},
  {id:5, name:"Women's premium kurti", sku:"AF-KUR-05", cat:"Women", label:"KUR", price:1200, stock:12, lowAt:5,
   desc:"Blossom Elegance kurti made from 100% cotton Joypuri fabric, lightweight and breathable. Features a delicate all-over print with playful tassel detailing, perfect for everyday wear or special occasions.",
   sizes:["S","M","L","XL"], colors:["#D4537E","#FAC775"]},
  {id:6, name:"Argentina player edition jersey", sku:"AF-ARG-06", cat:"Sports", label:"ARG", price:650, stock:18, lowAt:8,
   desc:"Premium quality sports jersey in fine polyester fabric — smooth, comfortable, and built for both match day and casual wear.",
   sizes:["S","M","L","XL","2XL"], colors:["#85B7EB","#FFFFFF"]},
  {id:7, name:"Men's premium t-shirt", sku:"AF-MEN-07", cat:"Men", label:"MEN", price:300, stock:30, lowAt:10,
   desc:"Combed compact cotton t-shirt with a smoother, silkier feel and a structured mid-weight fit. Compact construction ensures length and width hold steady over months of wear and washing.",
   sizes:["S","M","L","XL"], colors:["#10151F","#E24B4A"]},
  {id:8, name:"Custom sports jersey", sku:"AF-CUS-08", cat:"Custom", label:"CUS", price:750, stock:15, lowAt:5,
   desc:"Fully customisable jersey — add your own name, number, and team logo via digital sublimation printing. Minimum order 10 pieces for team orders.",
   sizes:["S","M","L","XL","2XL"], colors:["#C8283B","#173404","#0C447C"]}
];

/* ---------- low-level storage helpers ---------- */
function afRead(key, fallback){
  try{
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  }catch(e){ return fallback; }
}
function afWrite(key, value){
  localStorage.setItem(key, JSON.stringify(value));
}

/* ---------- products ---------- */
function afGetProducts(){
  let products = afRead(AF_KEYS.products, null);
  if(!products){
    products = AF_DEFAULT_PRODUCTS;
    afWrite(AF_KEYS.products, products);
    afWrite(AF_KEYS.productCodeCounter, 8);
  }
  return products;
}
function afSaveProducts(products){ afWrite(AF_KEYS.products, products); }

function afNextProductCode(){
  let counter = afRead(AF_KEYS.productCodeCounter, 8);
  counter++;
  afWrite(AF_KEYS.productCodeCounter, counter);
  return 'AF-P' + String(counter).padStart(4, '0');
}

function afAddProduct({name, price, stock, lowAt}){
  const products = afGetProducts();
  const code = afNextProductCode();
  const newId = products.length ? Math.max(...products.map(p => p.id)) + 1 : 1;
  const product = {
    id:newId, name, sku:code, cat:"Other", label: name.slice(0,3).toUpperCase(),
    price, stock, lowAt: lowAt || 5,
    desc:"", sizes:["S","M","L","XL"], colors:["#10151F"]
  };
  products.push(product);
  afSaveProducts(products);
  return product;
}

function afAdjustStock(id, delta){
  const products = afGetProducts();
  const p = products.find(p => p.id === id);
  if(!p) return;
  p.stock = Math.max(0, p.stock + delta);
  afSaveProducts(products);
}

function afReduceStockForItems(items){
  const products = afGetProducts();
  items.forEach(item => {
    const p = products.find(p => p.id === item.id);
    if(p) p.stock = Math.max(0, p.stock - item.qty);
  });
  afSaveProducts(products);
}

/* ---------- cart ---------- */
function afGetCart(){ return afRead(AF_KEYS.cart, []); }
function afSaveCart(cart){ afWrite(AF_KEYS.cart, cart); }

function afAddToCart(product, size, color, qty){
  const cart = afGetCart();
  const variantId = product.id + '-' + (size || 'std') + '-' + (color || 'std');
  const existing = cart.find(i => i.variantId === variantId);
  if(existing){ existing.qty += qty; }
  else {
    cart.push({
      id:product.id, variantId, name:product.name, sku:product.sku,
      price:product.price, label:product.label, size:size || null, color:color || null, qty
    });
  }
  afSaveCart(cart);
  return cart;
}
function afChangeCartQty(variantId, delta){
  let cart = afGetCart();
  const item = cart.find(i => i.variantId === variantId);
  if(!item) return cart;
  item.qty += delta;
  if(item.qty <= 0) cart = cart.filter(i => i.variantId !== variantId);
  afSaveCart(cart);
  return cart;
}
function afRemoveFromCart(variantId){
  const cart = afGetCart().filter(i => i.variantId !== variantId);
  afSaveCart(cart);
  return cart;
}
function afClearCart(){ afSaveCart([]); }
function afCartCount(){ return afGetCart().reduce((s,i) => s + i.qty, 0); }
function afCartSubtotal(){ return afGetCart().reduce((s,i) => s + i.price * i.qty, 0); }

/* ---------- invoices ---------- */
function afGetInvoices(){ return afRead(AF_KEYS.invoices, []); }
function afSaveInvoices(invoices){ afWrite(AF_KEYS.invoices, invoices); }

function afNextInvoiceNumber(){
  let counter = afRead(AF_KEYS.invoiceCounter, 1042);
  counter++;
  afWrite(AF_KEYS.invoiceCounter, counter);
  return 'INV-' + counter;
}

function afCreateInvoice({channel, customer, phone, address, items, payStatus}){
  const subtotal = items.reduce((s,i) => s + i.price * i.qty, 0);
  const invoice = {
    number: afNextInvoiceNumber(),
    channel, customer, phone: phone || 'N/A', address: address || '',
    items, subtotal, total: subtotal, payStatus,
    date: new Date().toLocaleDateString('en-GB'),
    time: new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})
  };
  const invoices = afGetInvoices();
  invoices.push(invoice);
  afSaveInvoices(invoices);
  afReduceStockForItems(items);
  return invoice;
}

/* ---------- shared UI helpers ---------- */
function afMoney(n){ return '৳' + Number(n).toLocaleString(); }

function afJerseySvg(label, size){
  size = size || 80;
  return `<svg viewBox="0 0 100 110" style="width:${size}px;height:${size*1.1}px;">
    <path d="M20 10 L35 2 L50 12 L65 2 L80 10 L95 28 L82 42 L78 34 L78 100 L22 100 L22 34 L18 42 L5 28 Z" fill="#F6F4EF"/>
    <text x="50" y="68" text-anchor="middle" font-family="Anton" font-size="22" fill="#C8283B">${label}</text>
  </svg>`;
}

function afUpdateCartBadge(){
  document.querySelectorAll('.js-cart-count').forEach(el => { el.textContent = afCartCount(); });
}

function afShowToast(msg){
  const el = document.getElementById('afToast');
  if(!el) return;
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(window._afToastTimer);
  window._afToastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}

document.addEventListener('DOMContentLoaded', () => {
  afGetProducts(); // ensure defaults are seeded
  afUpdateCartBadge();
});
