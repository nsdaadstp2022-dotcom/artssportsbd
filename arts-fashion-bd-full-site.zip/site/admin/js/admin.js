/* Shared admin logic — relies on ../js/store.js being loaded first */

const sampleCustomers = ["Rafiul Islam","Nusrat Jahan","Tanvir Ahmed","Sadia Sultana","Kamrul Hasan"];
let currentInvoiceFilter = 'all';

/* ---------- Dashboard ---------- */
function renderDashboard(){
  const products = afGetProducts();
  const invoices = afGetInvoices();
  const revenue = invoices.reduce((s,i) => s + i.total, 0);

  const totalEl = document.getElementById('statTotalProducts');
  const lowEl = document.getElementById('statLowStock');
  const invEl = document.getElementById('statInvoices');
  const revEl = document.getElementById('statRevenue');
  if(totalEl) totalEl.textContent = products.length;
  if(lowEl) lowEl.textContent = products.filter(p => p.stock <= p.lowAt).length;
  if(invEl) invEl.textContent = invoices.length;
  if(revEl) revEl.textContent = afMoney(revenue);

  const body = document.getElementById('recentActivityBody');
  if(!body) return;
  const recent = invoices.slice(-8).reverse();
  body.innerHTML = recent.length ? recent.map(inv => `
    <tr>
      <td>${inv.number}</td>
      <td><span class="badge ${inv.channel === 'Online' ? 'badge-online' : 'badge-offline'}">${inv.channel}</span></td>
      <td>${inv.customer}</td>
      <td>${inv.items.reduce((s,i)=>s+i.qty,0)} items</td>
      <td>${afMoney(inv.total)}</td>
      <td>${inv.time}</td>
    </tr>
  `).join('') : `<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:24px;">No activity yet — simulate an online order or create a manual invoice.</td></tr>`;
}

function simulateOnlineOrder(){
  const products = afGetProducts();
  const inStock = products.filter(p => p.stock > 0);
  if(inStock.length === 0){ alert('All products are out of stock — restock inventory first.'); return; }
  const numItems = Math.random() > 0.5 ? 2 : 1;
  const chosen = [];
  for(let i=0; i<numItems; i++){
    const p = inStock[Math.floor(Math.random()*inStock.length)];
    const qty = Math.min(p.stock, Math.floor(Math.random()*2)+1);
    if(qty > 0 && !chosen.find(c=>c.id===p.id)) chosen.push({id:p.id, name:p.name, sku:p.sku, price:p.price, qty});
  }
  const customer = sampleCustomers[Math.floor(Math.random()*sampleCustomers.length)];
  afCreateInvoice({ channel:'Online', customer, phone:'01XXXXXXXXX', items:chosen, payStatus:'paid' });
  renderDashboard();
  if(document.getElementById('inventoryBody')) renderInventory();
  if(document.getElementById('invoicesBody')) renderInvoices();
}

/* ---------- Inventory ---------- */
function stockStatus(p){
  if(p.stock <= 0) return {label:'Out of stock', cls:'stock-out'};
  if(p.stock <= p.lowAt) return {label:'Low stock', cls:'stock-low'};
  return {label:'In stock', cls:'stock-ok'};
}

function renderInventory(){
  const products = afGetProducts();
  const body = document.getElementById('inventoryBody');
  if(!body) return;
  body.innerHTML = products.map(p => {
    const st = stockStatus(p);
    return `
      <tr>
        <td><div class="prod-name">${p.name}</div></td>
        <td><span style="font-family:'Anton',sans-serif;font-size:13px;letter-spacing:0.3px;">${p.sku}</span></td>
        <td>${afMoney(p.price)}</td>
        <td>${p.stock} units</td>
        <td><span class="stock-badge ${st.cls}">${st.label}</span></td>
        <td class="no-print">
          <span class="qty-adjust">
            <button onclick="adjustStock(${p.id},-1)">&minus;</button>
            <button onclick="adjustStock(${p.id},1)">+</button>
          </span>
        </td>
      </tr>`;
  }).join('');
}

function adjustStock(id, delta){
  afAdjustStock(id, delta);
  renderInventory();
  if(document.getElementById('statTotalProducts')) renderDashboard();
}

function nextProductCodePreview(){ return afNextProductCode.toString ? null : null; }

function openAddProduct(){
  const products = afGetProducts();
  // Preview only — the real code is assigned on save to avoid burning codes on cancel
  document.getElementById('newProdCode').value = 'Assigned on save';
  document.getElementById('newProdName').value = '';
  document.getElementById('newProdPrice').value = '';
  document.getElementById('newProdStock').value = '';
  document.getElementById('newProdLowAt').value = 5;
  document.getElementById('addProductError').style.display = 'none';
  document.getElementById('addProductModal').classList.add('open');
}
function closeAddProduct(){
  document.getElementById('addProductModal').classList.remove('open');
}
function saveNewProduct(){
  const name = document.getElementById('newProdName').value.trim();
  const price = parseFloat(document.getElementById('newProdPrice').value);
  const stock = parseInt(document.getElementById('newProdStock').value);
  const lowAt = parseInt(document.getElementById('newProdLowAt').value) || 5;

  if(!name || isNaN(price) || price <= 0 || isNaN(stock) || stock < 0){
    document.getElementById('addProductError').style.display = 'block';
    return;
  }
  afAddProduct({name, price, stock, lowAt});
  closeAddProduct();
  renderInventory();
  if(document.getElementById('statTotalProducts')) renderDashboard();
}

/* ---------- Invoices ---------- */
function filterInvoices(type, btn){
  currentInvoiceFilter = type;
  document.querySelectorAll('#filterAllBtn, #filterOnlineBtn, #filterOfflineBtn').forEach(b => b.classList.remove('active-filter'));
  btn.classList.add('active-filter');
  renderInvoices();
}

function renderInvoices(){
  const body = document.getElementById('invoicesBody');
  if(!body) return;
  const invoices = afGetInvoices();
  const filtered = currentInvoiceFilter === 'all' ? invoices : invoices.filter(i => i.channel === currentInvoiceFilter);
  body.innerHTML = filtered.length ? filtered.slice().reverse().map(inv => `
    <tr>
      <td>${inv.number}</td>
      <td><span class="badge ${inv.channel === 'Online' ? 'badge-online' : 'badge-offline'}">${inv.channel}</span></td>
      <td>${inv.customer}</td>
      <td>${inv.date}</td>
      <td>${afMoney(inv.total)}</td>
      <td><span class="badge ${inv.payStatus === 'paid' ? 'badge-paid' : 'badge-due'}">${inv.payStatus === 'paid' ? 'Paid' : 'Due'}</span></td>
      <td class="no-print"><button class="btn btn-outline btn-sm" onclick="viewInvoice('${inv.number}')">View</button></td>
    </tr>
  `).join('') : `<tr><td colspan="7" style="text-align:center;color:var(--muted);padding:24px;">No ${currentInvoiceFilter === 'all' ? '' : currentInvoiceFilter.toLowerCase() + ' '}invoices yet.</td></tr>`;
}

function viewInvoice(number){
  const inv = afGetInvoices().find(i => i.number === number);
  document.getElementById('invoiceDocBody').innerHTML = `
    <div class="inv-head">
      <div><div class="inv-brand">ARTS FASHION BD<small>Sportswear &amp; Custom Jerseys</small></div></div>
      <div class="inv-meta"><strong>${inv.number}</strong><br>${inv.date} &middot; ${inv.time}<br>Channel: ${inv.channel}</div>
    </div>
    <div class="inv-parties">
      <div><h4>Billed to</h4>${inv.customer}<br>${inv.phone}${inv.address ? '<br>' + inv.address : ''}</div>
      <div style="text-align:right;"><h4>From</h4>Arts Fashion BD<br>182/2, Mudafa, Tongi, Gazipur-1711</div>
    </div>
    <table class="inv-table">
      <thead><tr><th>Item</th><th>Code</th><th>Qty</th><th>Price</th><th style="text-align:right;">Amount</th></tr></thead>
      <tbody>${inv.items.map(i => `<tr><td>${i.name}</td><td>${i.sku || '—'}</td><td>${i.qty}</td><td>${afMoney(i.price)}</td><td style="text-align:right;">${afMoney(i.price*i.qty)}</td></tr>`).join('')}</tbody>
    </table>
    <div class="inv-totals">
      <div><span>Subtotal</span><span>${afMoney(inv.subtotal)}</span></div>
      <div class="grand"><span>Total</span><span>${afMoney(inv.total)}</span></div>
      <div style="margin-top:8px;"><span>Payment status</span><span>${inv.payStatus === 'paid' ? 'Paid' : 'Due'}</span></div>
    </div>
    <div class="inv-footer">Thank you for your business — Arts Fashion BD</div>
  `;
  document.getElementById('invoiceViewModal').classList.add('open');
}
function closeInvoiceView(){ document.getElementById('invoiceViewModal').classList.remove('open'); }

/* ---------- Manual invoice ---------- */
function openManualInvoice(){
  document.getElementById('manCustName').value = '';
  document.getElementById('manCustPhone').value = '';
  document.getElementById('manPayStatus').value = 'paid';
  document.getElementById('lineItems').innerHTML = '';
  document.getElementById('manualError').style.display = 'none';
  addLineItem();
  updateManualTotals();
  document.getElementById('manualModal').classList.add('open');
}
function closeManualModal(){ document.getElementById('manualModal').classList.remove('open'); }

function addLineItem(){
  const products = afGetProducts();
  const row = document.createElement('div');
  row.className = 'line-item-row';
  row.innerHTML = `
    <select onchange="updateManualTotals()">
      <option value="">Select product</option>
      ${products.map(p => `<option value="${p.id}">${p.name} — ${p.sku} (${p.stock} in stock)</option>`).join('')}
    </select>
    <input type="number" min="1" value="1" onchange="updateManualTotals()" placeholder="Qty">
    <input type="text" disabled placeholder="Price">
    <input type="text" disabled placeholder="Amount">
    <span class="remove-line" onclick="this.parentElement.remove(); updateManualTotals();">&times;</span>
  `;
  document.getElementById('lineItems').appendChild(row);
}

function updateManualTotals(){
  const products = afGetProducts();
  const rows = document.querySelectorAll('#lineItems .line-item-row');
  let subtotal = 0;
  rows.forEach(row => {
    const select = row.querySelector('select');
    const inputs = row.querySelectorAll('input');
    const p = products.find(p => p.id === parseInt(select.value));
    const qty = parseInt(inputs[0].value) || 0;
    if(p){
      inputs[1].value = afMoney(p.price);
      const amount = p.price * qty;
      inputs[2].value = afMoney(amount);
      subtotal += amount;
    } else {
      inputs[1].value = '';
      inputs[2].value = '';
    }
  });
  document.getElementById('manualTotals').innerHTML = `
    <div><span>Subtotal</span><span>${afMoney(subtotal)}</span></div>
    <div class="grand"><span>Total</span><span>${afMoney(subtotal)}</span></div>
  `;
}

function saveManualInvoice(){
  const products = afGetProducts();
  const custName = document.getElementById('manCustName').value.trim();
  const custPhone = document.getElementById('manCustPhone').value.trim();
  const payStatus = document.getElementById('manPayStatus').value;
  const rows = document.querySelectorAll('#lineItems .line-item-row');
  const items = [];
  let valid = custName.length > 0 && rows.length > 0;

  rows.forEach(row => {
    const select = row.querySelector('select');
    const qty = parseInt(row.querySelectorAll('input')[0].value) || 0;
    const p = products.find(p => p.id === parseInt(select.value));
    if(!p || qty <= 0){ valid = false; return; }
    if(qty > p.stock){ valid = false; return; }
    items.push({id:p.id, name:p.name, sku:p.sku, price:p.price, qty});
  });

  if(!valid || items.length === 0){
    document.getElementById('manualError').textContent = 'Please complete all item rows (check stock availability) and enter a customer name.';
    document.getElementById('manualError').style.display = 'block';
    return;
  }

  afCreateInvoice({ channel:'Offline', customer:custName, phone:custPhone, items, payStatus });

  closeManualModal();
  renderInventory();
  renderInvoices();
  if(document.getElementById('statTotalProducts')) renderDashboard();
}
